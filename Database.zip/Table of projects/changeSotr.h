#ifndef CHANGESOTR_H_INCLUDED
#define CHANGESOTR_H_INCLUDED

void ShowChangeSotr();
int SpisDoljn();
int SpisSotrudnichestvo();
#endif // CHANGESOTR_H_INCLUDED
