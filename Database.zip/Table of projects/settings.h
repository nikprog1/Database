#ifndef SETTINGS_H_INCLUDED
#define SETTINGS_H_INCLUDED

void ShowSettings();

#endif // SETTINGS_H_INCLUDED
