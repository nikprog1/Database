#ifndef PROJECTS_H_INCLUDED
#define PROJECTS_H_INCLUDED

void ShowProjects();
int ReloadProjects(int proj);
void ShowFound();
int ShowQuestion();
int ShowQuestionAdd();
#endif // PROJECTS_H_INCLUDED
