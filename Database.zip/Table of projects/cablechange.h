#ifndef CABLECHANGE_H_INCLUDED
#define CABLECHANGE_H_INCLUDED

void ShowCable();
int ChangeUst(char Heat_object[100]);
#endif // CABLECHANGE_H_INCLUDED
