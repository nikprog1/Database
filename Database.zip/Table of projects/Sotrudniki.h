#ifndef SOTRUDNIKI_H_INCLUDED
#define SOTRUDNIKI_H_INCLUDED

int LoadSotr ();
void ShowSotr();
int ReloadSotr();
int StatusSotr();
#endif // SOTRUDNIKI_H_INCLUDED
