#ifndef PASSWORD_H_INCLUDED
#define PASSWORD_H_INCLUDED
int res;
int comparision();
int ShowPassword();
int ShowInfo();
int ShowMainWindow();
#endif // PASSWORD_H_INCLUDED
