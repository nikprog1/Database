#ifndef CHANGE_H_INCLUDED
#define CHANGE_H_INCLUDED

void ShowChange(int proj);
int ReloadNakl(int nakl);

#endif // CHANGE_H_INCLUDED
